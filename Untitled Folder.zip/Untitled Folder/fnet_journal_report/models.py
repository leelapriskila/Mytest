# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class fnet_journal_report(models.Model):
#     _name = 'fnet_journal_report.fnet_journal_report'

#     name = fields.Char()