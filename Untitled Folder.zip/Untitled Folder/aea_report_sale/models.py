# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class aea_report_sale(models.Model):
#     _name = 'aea_report_sale.aea_report_sale'

#     name = fields.Char()