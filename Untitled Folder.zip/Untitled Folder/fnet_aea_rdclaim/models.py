# -*- coding: utf-8 -*-

from openerp import models, fields, api

# class rdclaim_xls(models.Model):
#     _name = 'rdclaim_xls.rdclaim_xls'

#     name = fields.Char()