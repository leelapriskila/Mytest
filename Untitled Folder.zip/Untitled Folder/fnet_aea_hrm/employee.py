from openerp.osv import fields, osv
import datetime
import openerp.addons.decimal_precision as dp

class hr_contract(osv.osv):

    _inherit = 'hr.contract'


    def _payment_term(self, cr, uid, ids, field_name, arg, context=None):
        res = {}
        if context is None:
            context = {}
        for line in self.browse(cr, uid, ids, context=context):
            if line.advance_amount and line.monthly_deduction:
                res[line.id] = round(line.advance_amount/line.monthly_deduction)
        return res
        
    _columns={
        
        'advance_amount':fields.float('Advance'),
        'monthly_deduction':fields.float('Monthly Deduction',default=1.0),
        'payment_term':fields.function(_payment_term, string='Payment Term',type='float',digits_compute=dp.get_precision('Discount'),store=True,help='Total number of month to pay for Loan amount'),
        'lunch_expense':fields.float('Lunch Expense'),
        'tax_deuduction':fields.float('Income Tax deduction'),
        'other_deduction_1':fields.float('Other deduction 1'),
        'other_deduction_2':fields.float('Other deduction 2'),
        'hra':fields.float('HRA'),
        'special_allowance':fields.float('Special allowance'),
        'convance':fields.float('Convance'),
        'leave_allownace':fields.float('Leave Allowance'),
        'medical_allownace':fields.float('Medical Allowance'),
    }

class hr_payslip(osv.osv):
    
    _inherit='hr.payslip'
    
    _columns={
        'lop':fields.float('LOP',readonly=True),
        'no_of_days':fields.float('No of days',readonly=True),
    }

            
    def create(self, cr, uid, vals, context=None):
        from_dt = datetime.datetime.strptime(vals.get('date_from'), '%Y-%m-%d')
        to_dt = datetime.datetime.strptime(vals.get('date_to'), '%Y-%m-%d')
        delta=to_dt-from_dt
        emp_id=vals.get('employee_id')
        holiday_rec=self.pool.get('hr.holidays')
        holiday_id=holiday_rec.search(cr,uid,[('holiday_status_id','=',4),('date_to','>=',vals.get('date_from')),('date_to','<=',vals.get('date_to')),('employee_id','=',emp_id)],context=context)
        rec=holiday_rec.browse(cr,uid,holiday_id,context=context)
        lop=0.0
        for val in rec:
            lop=lop+val.number_of_days_temp
        vals.update({'lop':lop,'no_of_days':delta.days})
        new_id = super(hr_payslip, self).create(cr, uid, vals, context=context)
        return new_id
        
    def compute_sheet(self,cr,uid,ids,context=None):
        new_id = super(hr_payslip, self).compute_sheet(cr, uid,ids,context=context)
        for payslip in self.browse(cr, uid, ids, context=context):
            contract_ids = self.get_contract(cr, uid, payslip.employee_id, payslip.date_from, payslip.date_to, context=context)
            contract_val=self.pool.get('hr.contract')
            contract_rec=contract_val.browse(cr,uid,contract_ids,context=context)
            new_adv=0.0
            new_term=0.0
            if contract_rec.advance_amount >0 and contract_rec.payment_term>0:
                new_adv=contract_rec.advance_amount-contract_rec.monthly_deduction
                new_term=new_term-1
                contract_val.write(cr, uid, contract_ids, {'advance_amount': new_adv, 'payment_term': new_term,}, context=context)         
        return True
        
    def cancel_sheet(self, cr, uid, ids, context=None):
        rec=super(hr_payslip, self).cancel_sheet(cr, uid,ids,context=context)
        for payslip in self.browse(cr, uid, ids, context=context):
            contract_ids = self.get_contract(cr, uid, payslip.employee_id, payslip.date_from, payslip.date_to, context=context)
            contract_val=self.pool.get('hr.contract')
            contract_rec=contract_val.browse(cr,uid,contract_ids,context=context)
            new_adv=0.0
            new_term=0.0
            if contract_rec.advance_amount >0 and contract_rec.payment_term>0:
                new_adv=contract_rec.advance_amount+contract_rec.monthly_deduction
                new_term=new_term+1
                contract_val.write(cr, uid, contract_ids, {'advance_amount': new_adv, 'payment_term': new_term,}, context=context)
        return rec

class hr_employee(osv.osv):
    
    _inherit='hr.employee'
    
    _columns={
        'tkn_no':fields.char('Tkn.No'),
        'pf_no':fields.char('P.F.No'),
        'esi_no':fields.char('E.S.I.No'),
        'father_name':fields.char('F/H Name'),
        'doj':fields.date('D.O.J'),
        'emp_code':fields.char('Employee Code'),
    }
