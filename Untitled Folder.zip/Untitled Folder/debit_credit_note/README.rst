Debit and Credit Notes on Invoice
=================================

This module add credit a debit notes on each invoices

This module add:

- A new button on invoice to generate debit note
- Parent_id field to set principal invoice from which the credit note
