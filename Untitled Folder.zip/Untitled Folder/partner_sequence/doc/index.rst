In Odoo normally partners do only have a name.
You can use this module for assinging a clear reference to a partner.
A partner can be a supplier or a customer. 

Start by defining a sequence in the Settings menu:

    **Sequences & Identifiers > Sequences**

Apply a proper name like "Partner" and Sequence Type "Partner".
Give a prefix in order to have a unambiguous reference.


A reference like this can also be set on a product. Look for the Onestein module for this in the Apps store.

|

**Contact us:**

When you have any remark about this module, please let us know on http://www.onestein.eu/feedback
