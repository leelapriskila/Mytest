
# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-today OpenERP SA (<http://www.openerp.com>)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################
import time
from datetime import date
from datetime import datetime
from datetime import timedelta
from dateutil import relativedelta

from openerp import api, tools
from openerp.osv import fields, osv
from openerp.tools.translate import _
import openerp.addons.decimal_precision as dp


class mline_payroll_rule(osv.osv):
    _name = 'mline.payroll.rule'
    _columns = {
           'name':fields.char('Name', size=64, required=True),
           'code':fields.char('Code', size=64, required=True),
           'type': fields.selection([('add', 'Add'),('remove', 'Remove')], 'Type',required=True),
           'debit_account_id': fields.many2one('account.account', 'Debit Account'),
           'credit_account_id': fields.many2one('account.account', 'Credit Account'),
               }
    _defaults = {
         'type':'add',
          }
          
    def draft(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids, {'state': 'draft'})
        
mline_payroll_rule()

class mline_payroll(osv.osv):
    _name = 'mline.payroll'
    _columns = {
           'name':fields.char('Name', size=64, readonly=True, required=True),
           'employee_id': fields.many2one('hr.employee', 'Employee', required=True),
           'job_id':fields.many2one('hr.job', 'Designation'),
           'emp_id':fields.char('Employee Id', size=64),
           'contract_id':fields.many2one('hr.contract', 'Contract'),
           'branch_id':fields.many2one('company.branch', 'Company'),
           'date_from':fields.date('From Date', required=True), 
           'date_to':fields.date('To Date', required=True),
           'move_id':fields.many2one('account.move', 'Journal Entries'),
           'state': fields.selection([
                ('draft', 'Draft'),
                ('compute', 'Computation'),
                ('done', 'Done'),
                ('cancel', 'Cancelled'),
                        ], 'Status', readonly=True),
           'working_line':fields.one2many('mline.working.line', 'payroll_id', 'Working'),
           'salary_line':fields.one2many('mline.payroll.line', 'payroll_id', 'Payroll'),
             }
   
    _defaults = {
        'date_from': lambda *a: time.strftime('%Y-%m-01'),
        'date_to': lambda *a: str(datetime.now() + relativedelta.relativedelta(months=+1, day=1, days=-1))[:10],
        'state': 'draft',
        'name': lambda x, y, z, c: x.pool.get('ir.sequence').get(y, z, 'mline.payroll') or '/',     
               }
               
    def worked_days(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids)
        det = obj.date_from
        year_obj, month_obj, day = (int(x) for x in det.split('-'))
        cr.execute('''select 
                            sum(ot_hours) as ot,
                            sum(holiday_hours) as hol
                      from hr_timesheet_sheet_sheet
                      where employee_id = '%s' and state='done' and to_char(date_from, 'MM')='%s' 
                      and to_char(date_from, 'YYYY')='%s' ''' % (obj.employee_id.id, str(month_obj).zfill(2), str(year_obj)))
        time = cr.dictfetchall()
        cr.execute(''' select 
                            sum(hh.number_of_days) as days
                       from hr_holidays hh
                       join hr_holidays_status hhs on (hhs.id = hh.holiday_status_id)
                       where hh.employee_id = '%s' and hhs.name='Unpaid' and hh.state='validate' and to_char(hh.date_from, 'MM')='%s' 
                       and to_char(date_from, 'YYYY')='%s' ''' % (obj.employee_id.id, str(month_obj).zfill(2), str(year_obj)))
        leave = cr.dictfetchall()
        le = 0.00
        if leave[0]['days'] is None:
            le = 0.00
        else:
            le = abs(leave[0]['days'])
        pay_sr = self.pool.get('mline.working.line').search(cr, uid, [('payroll_id', '=', obj.id)], context=context)
        if not pay_sr:
            vals = { 
               'payroll_id':obj.id,
               'ot_hours':time[0]['ot'],
               'holiday_hours':time[0]['hol'],
               'leave_days':le
               }
            self.pool.get('mline.working.line').create(cr, uid, vals, context=context)
        return self.write(cr, uid, ids, {'state': 'compute'}, context=context)
        
    def _get_datas(self, cr, uid, obj, context=None):
        data = []
        ots = {}
        hols = {}
        leave = {}
        rule = self.pool.get('mline.payroll.rule')
        for line in obj.working_line:
            ot = line.ot_hours * obj.contract_id.ot_price
            hol = line.holiday_hours * obj.contract_id.holiday_price
            le =  (line.leave_days * 8) * obj.contract_id.normal_price
            if line.leave_days == 0.00:
                ru = rule.search(cr, uid, [('code', 'in', ('OT', 'HOL'))], context=context)
                for rul_id in rule.browse(cr, uid, ru):
                    if rul_id.code == 'OT' and ot <> 0.00:
                        ots['amd'] = ot
                        ots['rule'] = rul_id.id
                        data.append(ots)
                    else:
                        if hol <> 0.00:
                            hols['amd'] = hol
                            hols['rule'] = rul_id.id
                            data.append(hols)
            else:
                ru = rule.search(cr, uid, [('code', 'in', ('OT', 'HOL', 'LEAVE'))], context=context)
                for rul_id in rule.browse(cr, uid, ru):
                    if rul_id.code == 'OT' and ot <> 0.00:
                        ots['amd'] = ot
                        ots['rule'] = rul_id.id
                        data.append(ots)
                    elif rul_id.code == 'HOL' and hol <> 0.00:
                        hols['amd'] = hol
                        hols['rule'] = rul_id.id
                        data.append(hols)
                    else:
                        if len(leave) < 1 and rul_id.code not in ('OT', 'HOL'):
                            leave['amd'] = le
                            leave['rule'] = rul_id.id
                            data.append(leave)
        return data  
          
          
    def compute_sheet(self, cr, uid, ids, context=None):
        cont = self.pool.get('hr.contract')
        sal = self.pool.get('mline.payroll.line')
        rule = self.pool.get('mline.payroll.rule')
        obj = self.browse(cr, uid, ids)
        gross_rule = rule.search(cr, uid, [('code', '=', 'GROSS')], context=context)
        net_rule = rule.search(cr, uid, [('code', '=', 'NET')], context=context)
        work = [line for line in obj.working_line]
        if work:
            cr.execute(''' SELECT 
                                hcl.rule_id as rule,
                                hcl.amount as amd
                           FROM hr_contract hc
                           JOIN hr_contract_line hcl ON (hcl.contract_id = hc.id)
                           WHERE hc.id = '%s'
                           order by 1 ''' % (obj.contract_id.id))
            sala = cr.dictfetchall()
            data = self._get_datas(cr, uid, obj, context=context)
            sal_sr = sal.search(cr, uid, [('payroll_id', '=', obj.id)], context=context)
            if not sal_sr:
                for line in sala:
                    val = {
                     'payroll_id':obj.id,
                     'rule_id':line['rule'],
                     'amount':line['amd']
                      }
                    sal.create(cr, uid, val, context=context)
                for datas in data:
                    vals = {
                     'payroll_id':obj.id,
                     'rule_id':datas['rule'],
                     'amount':datas['amd']
                      }
                    sal.create(cr, uid, vals, context=context)
                cr.execute(''' SELECT 
                                     sum(amount) as gross
                               FROM mline_payroll_line
                               WHERE payroll_id = '%s' ''' % (obj.id))
                gross = cr.dictfetchall()
                cr.execute(''' SELECT 
                                    ROUND(sum(amount)) as net
                               FROM mline_payroll_line mpl
                               JOIN mline_payroll_rule mpr ON (mpr.id = mpl.rule_id)
                               WHERE mpl.payroll_id= '%s' and mpr.type = 'add' ''' % (obj.id))
                net = cr.dictfetchall()
                gro_val = {
                         'payroll_id':obj.id,
                         'rule_id':gross_rule[0],
                         'amount':gross[0]['gross']
                         }
                sal.create(cr, uid, gro_val, context=context)
                gro_val = {
                         'payroll_id':obj.id,
                         'rule_id':net_rule[0],
                         'amount':net[0]['net']
                         }
                sal.create(cr, uid, gro_val, context=context)
            else:
                sal_sr1 = sal.search(cr, uid, [('payroll_id', '=', obj.id)], context=context)
                sal.unlink(cr, uid, sal_sr1, context=context)
                for line in sala:
                    val = {
                     'payroll_id':obj.id,
                     'rule_id':line['rule'],
                     'amount':line['amd']
                      }
                    sal.create(cr, uid, val, context=context)
                for datas in data:
                    vals = {
                     'payroll_id':obj.id,
                     'rule_id':datas['rule'],
                     'amount':datas['amd']
                      }
                    sal.create(cr, uid, vals, context=context)
                cr.execute(''' SELECT 
                                     sum(amount) as gross
                               FROM mline_payroll_line
                               WHERE payroll_id = '%s' ''' % (obj.id))
                gross = cr.dictfetchall()
                cr.execute(''' SELECT 
                                    ROUND(sum(amount)) as net
                               FROM mline_payroll_line mpl
                               JOIN mline_payroll_rule mpr ON (mpr.id = mpl.rule_id)
                               WHERE mpl.payroll_id= '%s' and mpr.type = 'add' ''' % (obj.id))
                net = cr.dictfetchall()
                gro_val = {
                         'payroll_id':obj.id,
                         'rule_id':gross_rule[0],
                         'amount':gross[0]['gross']
                         }
                sal.create(cr, uid, gro_val, context=context)
                gro_val = {
                         'payroll_id':obj.id,
                         'rule_id':net_rule[0],
                         'amount':net[0]['net']
                         }
                sal.create(cr, uid, gro_val, context=context)
        else:
            raise osv.except_osv(_('Warning!'), _('First Update Employee Work Days'))
        return True
        
    def confirm(self, cr, uid, ids, context=None):
        line_ids = []
        obj = self.browse(cr, uid, ids)
        move_pool = self.pool.get('account.move')
        move_line_pool = self.pool.get('account.move.line')
        period_pool = self.pool.get('account.period')
        rule = self.pool.get('mline.payroll.rule')
        gross_rule = rule.search(cr, uid, [('code', '=', 'GROSS')], context=context)
        net_rule = rule.search(cr, uid, [('code', '=', 'NET')], context=context)
        precision = self.pool.get('decimal.precision').precision_get(cr, uid, 'Payroll')
        timenow = time.strftime('%Y-%m-%d')
        default_partner_id = obj.employee_id.address_home_id.id
        date = timenow
        search_periods = period_pool.find(cr, uid, date, context=context)
        period_id = search_periods[0]
        name = _('Payslip of %s') % (obj.employee_id.name)
        move = {
                'narration': name,
                'date': timenow,
                'ref': obj.name,
                'journal_id': obj.employee_id.journal_salary_id.id,
                'period_id': period_id,
            }
        move_id = move_pool.create(cr, uid, move, context=context)
        for line in obj.salary_line:
            if line.rule_id.id == net_rule[0]:
                debit_li = {
                         'move_id':move_id,
                         'name':line.rule_id.name,
                         'date': timenow,
                         'partner_id':default_partner_id,
                         'account_id':obj.employee_id.debit_account_id.id,
                         'journal_id':obj.employee_id.journal_salary_id.id,
                         'period_id':period_id,
                         'debit':0.0,
                         'credit':line.amount,
                 }
                move_line_pool.create(cr, uid, debit_li, context=context)
            if line.rule_id.id == net_rule[0]:
                credit_li = {
                         'move_id':move_id,
                         'name':line.rule_id.name,
                         'date': timenow,
                         'partner_id':default_partner_id,
                         'account_id':obj.employee_id.credit_account_id.id,
                         'journal_id':obj.employee_id.journal_salary_id.id,
                         'period_id':period_id,
                         'debit':line.amount,
                         'credit':0.0
                         }
                move_line_pool.create(cr, uid, credit_li, context=context)
        self.write(cr, uid, obj.id, {'move_id':move_id}, context=context)
        return self.write(cr, uid, obj.id, {'state':'done'}, context=context)
    
    def cancel(self, cr, uid, ids, context=None):
        move_pool = self.pool.get('account.move')
        obj = self.browse(cr, uid, ids)
        if obj.move_id.id:
            if obj.employee_id.journal_salary_id.update_posted is True:
                move_pool.button_cancel(cr, uid, [obj.move_id.id], context=context)
                move_pool.unlink(cr, uid, [obj.move_id.id], context=context)
            else:
                raise osv.except_osv(_('Error!'), _('You cannot modify a posted entry of this journal.First you should set the journal to allow cancelling entries'))
        return self.write(cr, uid, obj.id, {'state':'cancel'}, context=context)
    
    def unlink(self, cr, uid, ids, context=None):
        payroll = self.read(cr, uid, ids, ['state'], context=context)
        unlink_ids = []
        for s in payroll:
            if s['state'] in ['draft', 'cancel']:
                unlink_ids.append(s['id'])
            else:
                raise osv.except_osv(_('Invalid Action!'), _('You must cancel it before! delete Payslip'))

        return osv.osv.unlink(self, cr, uid, unlink_ids, context=context)
    
    def set_dtaft(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids)
        work_line = self.pool.get('mline.working.line')
        pay_line = self.pool.get('mline.payroll.line')
        work_sr = work_line.search(cr, uid, [('payroll_id', '=', obj.id)], context=context)
        pay_sr = pay_line.search(cr, uid, [('payroll_id', '=', obj.id)], context=context)
        work_line.unlink(cr, uid, work_sr, context=context)
        pay_line.unlink(cr, uid, pay_sr, context=context)
        return self.write(cr, uid, obj.id, {'state':'draft'}, context=context)
          
    def onchange_employee_id(self, cr, uid, ids, employee_id=False, contract_id=False, job_id=False, branch_id=True, context=None):
        employee_obj = self.pool.get('hr.employee')
        contract_obj = self.pool.get('hr.contract')
        job_obj = self.pool.get('hr.job')
        if context is None:
            context = {}
        values = {}
        if employee_id:
            emp = employee_obj.browse(cr, uid, employee_id, context=context)
            cont = contract_obj.search(cr, uid, [('employee_id', '=', emp.id)], context=context)
            if cont:
                cont_br = contract_obj.browse(cr, uid, cont[0])
                values = {
                      'emp_id':emp.emp_code,
                      'job_id':emp.job_id.id,
                      'contract_id':cont_br.id,
                      'branch_id':emp.branch_id.id,   
                         }
            else:
                raise osv.except_osv(_('Error!'), _('Please Create Employee related Internal Contract !!!'))
        return {'value': values}
mline_payroll()

class mline_working_line(osv.osv):
    _name = 'mline.working.line'
    _columns = {
    
        'payroll_id': fields.many2one('mline.payroll', 'Working'),
        'ot_hours': fields.float('OT Hours', readonly=True),
        'holiday_hours': fields.float('Holiday Hours', readonly=True),
        'leave_days': fields.float('Leave Days'),
             }
           
mline_working_line()

class mline_payroll_line(osv.osv):
    _name = 'mline.payroll.line'
    _columns = {
    
        'payroll_id': fields.many2one('mline.payroll', 'Payroll'),
        'rule_id':fields.many2one('mline.payroll.rule', 'Rule'),
        'amount':fields.float('Amount', readonly=True, digits_compute= dp.get_precision('Payroll')),
        
        }
mline_payroll_line()

