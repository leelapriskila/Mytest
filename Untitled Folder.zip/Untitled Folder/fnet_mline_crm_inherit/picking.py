# -*- coding: utf-8 -*-
##############################################################################
#
#    OpenERP, Open Source Management Solution
#    Copyright (C) 2004-today OpenERP SA (<http://www.openerp.com>)
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
##############################################################################

from openerp.osv import osv, fields

class stock_picking_inh(osv.osv):
    _inherit = "stock.picking"
    
    def _get_attachment_number(self, cr, uid, ids, fields, args, context=None):
        res = dict.fromkeys(ids, 0)
        for app_id in ids:
            res[app_id] = self.pool['ir.attachment'].search_count(cr, uid, [('res_model', '=', 'stock.picking'), ('res_id', '=', app_id)], context=context)
        return res

    
    _columns = {
         'lead_id':fields.many2one('crm.lead', 'Enquiry', readonly=True),   
         'lpo_no':fields.char('L.P.O No'),
         'country_origin':fields.many2one('res.country','Country of origin'),
         'courier_name':fields.char('Courier Name'),
         'courier_no':fields.char('Courier No.'),
         #~ attachments
         'attachment_number': fields.function(_get_attachment_number, string='Number of Attachments', type="integer"),
       }
       
    def action_get_attachment_picking_tree_view(self, cr, uid, ids, context=None):
        model, action_id = self.pool.get('ir.model.data').get_object_reference(cr, uid, 'base', 'action_attachment')
        action = self.pool.get(model).read(cr, uid, action_id, context=context)
        action['context'] = {'default_res_model': self._name, 'default_res_id': ids[0]}
        action['domain'] = str(['&', ('res_model', '=', self._name), ('res_id', 'in', ids)])
        return action
     
stock_picking_inh()

class stock_move_inh(osv.osv):
    _inherit = 'stock.move'
    _columns = {
    
         }
stock_move_inh()
